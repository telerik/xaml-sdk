﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace BindingRowDetailsElementWidth_SL
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
