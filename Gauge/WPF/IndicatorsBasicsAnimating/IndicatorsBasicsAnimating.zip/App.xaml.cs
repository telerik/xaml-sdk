﻿using System.Windows;

namespace IndicatorsBasicsAnimating
{
	public partial class App : Application
	{
	}
}
