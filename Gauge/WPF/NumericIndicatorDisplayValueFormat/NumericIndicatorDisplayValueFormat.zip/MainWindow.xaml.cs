﻿using System.Windows;

namespace NumericIndicatorDisplayValueFormat
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
