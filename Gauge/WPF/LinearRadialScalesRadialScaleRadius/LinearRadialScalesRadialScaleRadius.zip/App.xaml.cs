﻿using System.Windows;

namespace LinearRadialScalesRadialScaleRadius
{
	public partial class App : Application
	{
	}
}
