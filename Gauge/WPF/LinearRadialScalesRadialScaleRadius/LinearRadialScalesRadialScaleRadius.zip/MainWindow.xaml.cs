﻿using System.Windows;

namespace LinearRadialScalesRadialScaleRadius
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
