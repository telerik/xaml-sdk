﻿using System.Windows;

namespace RadialScaleBarIndicatorLayout
{
	public partial class App : Application
	{
	}
}
