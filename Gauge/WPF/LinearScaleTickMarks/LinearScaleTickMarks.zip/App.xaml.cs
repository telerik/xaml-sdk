﻿using System.Windows;

namespace LinearScaleTickMarks
{
	public partial class App : Application
	{
	}
}
