﻿using System.Windows;

namespace NumericIndicatorNumberPositions
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
