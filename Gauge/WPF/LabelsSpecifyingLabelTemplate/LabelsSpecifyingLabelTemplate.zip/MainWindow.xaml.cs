﻿using System.Windows;

namespace LabelsSpecifyingLabelTemplate
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
