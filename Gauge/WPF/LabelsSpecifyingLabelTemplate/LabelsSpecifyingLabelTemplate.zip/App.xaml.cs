﻿using System.Windows;

namespace LabelsSpecifyingLabelTemplate
{
	public partial class App : Application
	{
	}
}
