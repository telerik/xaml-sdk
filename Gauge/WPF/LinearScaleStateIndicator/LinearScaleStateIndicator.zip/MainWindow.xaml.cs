﻿using System.Windows;

namespace LinearScaleStateIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
