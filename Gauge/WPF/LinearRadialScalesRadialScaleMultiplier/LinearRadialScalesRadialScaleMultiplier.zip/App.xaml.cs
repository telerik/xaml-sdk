﻿using System.Windows;

namespace LinearRadialScalesRadialScaleMultiplier
{
	public partial class App : Application
	{
	}
}
