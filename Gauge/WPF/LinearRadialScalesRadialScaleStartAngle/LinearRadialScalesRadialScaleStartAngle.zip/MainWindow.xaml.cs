﻿using System.Windows;

namespace LinearRadialScalesRadialScaleStartAngle
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
