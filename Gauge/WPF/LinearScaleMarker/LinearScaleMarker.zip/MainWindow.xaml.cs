﻿using System.Windows;

namespace LinearScaleMarker
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
