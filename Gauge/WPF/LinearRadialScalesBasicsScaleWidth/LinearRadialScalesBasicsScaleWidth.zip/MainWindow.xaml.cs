﻿using System.Windows;

namespace LinearRadialScalesBasicsScaleWidth
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
