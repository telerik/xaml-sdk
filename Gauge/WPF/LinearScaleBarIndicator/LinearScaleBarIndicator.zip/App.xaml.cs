﻿using System.Windows;

namespace LinearScaleBarIndicator
{
	public partial class App : Application
	{
	}
}
