﻿using System.Windows;

namespace LabelsAppearance
{
	public partial class App : Application
	{
	}
}
