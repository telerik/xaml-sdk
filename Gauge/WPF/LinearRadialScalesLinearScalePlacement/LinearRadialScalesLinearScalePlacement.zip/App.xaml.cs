﻿using System.Windows;

namespace LinearRadialScalesLinearScalePlacement
{
	public partial class App : Application
	{
	}
}
