﻿using System.Windows;

namespace NumericIndicatorPlacement
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
