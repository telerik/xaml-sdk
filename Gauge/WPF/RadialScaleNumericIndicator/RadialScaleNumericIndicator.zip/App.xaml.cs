﻿using System.Windows;

namespace RadialScaleNumericIndicator
{
	public partial class App : Application
	{
	}
}
