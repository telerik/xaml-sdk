﻿using System.Windows;

namespace IndicatorsNeedle
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
