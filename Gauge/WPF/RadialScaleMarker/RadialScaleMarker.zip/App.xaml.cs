﻿using System.Windows;

namespace RadialScaleMarker
{
	public partial class App : Application
	{
	}
}
