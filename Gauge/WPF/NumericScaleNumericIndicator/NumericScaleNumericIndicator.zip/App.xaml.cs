﻿using System.Windows;

namespace NumericScaleNumericIndicator
{
	public partial class App : Application
	{
	}
}
