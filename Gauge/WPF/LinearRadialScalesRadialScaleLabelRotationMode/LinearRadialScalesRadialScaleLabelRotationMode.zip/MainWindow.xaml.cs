﻿using System.Windows;

namespace LinearRadialScalesRadialScaleLabelRotationMode
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
