﻿using System.Windows;

namespace RadialScaleLabels
{
	public partial class App : Application
	{
	}
}
