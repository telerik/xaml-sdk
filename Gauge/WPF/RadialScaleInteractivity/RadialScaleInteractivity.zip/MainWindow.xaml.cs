﻿using System.Windows;

namespace RadialScaleInteractivity
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
