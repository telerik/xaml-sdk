﻿using System.Windows;

namespace LinearRadialScalesRadialScaleSweepAngle
{
	public partial class App : Application
	{
	}
}
