﻿using System.Windows;

namespace RadialScaleQuadrantStyleGauge
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
