﻿using System.Windows;

namespace RadialScaleQuadrantStyleGauge
{
	public partial class App : Application
	{
	}
}
