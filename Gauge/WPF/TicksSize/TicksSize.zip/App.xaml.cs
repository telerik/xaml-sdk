﻿using System.Windows;

namespace TicksSize
{
	public partial class App : Application
	{
	}
}
