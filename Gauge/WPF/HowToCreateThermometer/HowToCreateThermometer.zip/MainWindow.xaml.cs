﻿using System.Windows;

namespace HowToCreateThermometer
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
