﻿using System.Windows;

namespace LabelsOffset
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
