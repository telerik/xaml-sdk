﻿using System.Windows;

namespace LinearScaleInteractivity
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}