﻿using System.Windows;

namespace NumericIndicatorCornerRadius
{
	public partial class App : Application
	{
	}
}
