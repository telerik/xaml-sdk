﻿using System.Windows;

namespace LabelsLocation
{
	public partial class App : Application
	{
	}
}
