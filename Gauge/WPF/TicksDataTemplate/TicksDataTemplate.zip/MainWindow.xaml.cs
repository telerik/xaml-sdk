﻿using System.Windows;

namespace TicksDataTemplate
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
