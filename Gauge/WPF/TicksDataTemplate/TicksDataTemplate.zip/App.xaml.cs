﻿using System.Windows;

namespace TicksDataTemplate
{
	public partial class App : Application
	{
	}
}
