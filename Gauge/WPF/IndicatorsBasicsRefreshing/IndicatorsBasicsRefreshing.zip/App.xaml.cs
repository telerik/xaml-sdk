﻿using System.Windows;

namespace IndicatorsBasicsRefreshing
{
	public partial class App : Application
	{
	}
}
