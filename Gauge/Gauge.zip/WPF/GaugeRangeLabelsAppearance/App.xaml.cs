﻿using System.Windows;

namespace GaugeRangeLabelsAppearance
{
	public partial class App : Application
	{
	}
}
