﻿using System.Windows;

namespace LabelsOffset
{
	public partial class App : Application
	{
	}
}
