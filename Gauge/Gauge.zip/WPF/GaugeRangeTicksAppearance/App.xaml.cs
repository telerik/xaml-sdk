﻿using System.Windows;

namespace GaugeRangeTicksAppearance
{
	public partial class App : Application
	{
	}
}
