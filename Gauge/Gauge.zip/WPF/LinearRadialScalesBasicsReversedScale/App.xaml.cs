﻿using System.Windows;

namespace LinearRadialScalesBasicsReversedScale
{
	public partial class App : Application
	{
	}
}
