﻿using System.Windows;

namespace GaugeRangeIndicatorColorMixSensitivity
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
