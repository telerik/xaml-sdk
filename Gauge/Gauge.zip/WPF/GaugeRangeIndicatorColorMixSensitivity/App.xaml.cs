﻿using System.Windows;

namespace GaugeRangeIndicatorColorMixSensitivity
{
	public partial class App : Application
	{
	}
}
