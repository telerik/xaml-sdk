﻿using System.Windows;

namespace IndicatorsNeedle
{
	public partial class App : Application
	{
	}
}
