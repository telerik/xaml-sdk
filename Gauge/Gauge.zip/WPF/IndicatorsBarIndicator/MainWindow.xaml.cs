﻿using System.Windows;

namespace IndicatorsBarIndicator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
