﻿using System.Windows.Controls;

namespace Groups
{
	public partial class RadialGaugeGroupsDemo : UserControl
	{
		public RadialGaugeGroupsDemo()
		{
			InitializeComponent();
		}
	}
}
