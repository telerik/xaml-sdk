﻿using System.Windows.Controls;

namespace Groups
{
	public partial class LinearGaugeGroupsDemo : UserControl
	{
		public LinearGaugeGroupsDemo()
		{
			InitializeComponent();
		}
	}
}
