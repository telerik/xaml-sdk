﻿The appearance of the ticks in the range can be controlled via the following properties:

   - TickBackground - specifies the fill color for the ticks that belong to the range.

To modify the appearance of the ticks via the range, they should be in Use Range Color mode.