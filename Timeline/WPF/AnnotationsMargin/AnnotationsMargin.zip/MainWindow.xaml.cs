﻿using System.Windows;

namespace AnnotationsMargin
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
