﻿using System;

namespace Grouping
{
	public class RadTimelineDataItem
	{
		public DateTime StartDate { get; set; }

		public TimeSpan Duration { get; set; }

		public string GroupName { get; set; }
	}
}
