﻿using System;

namespace AnnotationsZIndex
{
	public class RadTimelineDataItem
	{
		public DateTime StartDate { get; set; }

		public TimeSpan Duration { get; set; }
	}
}
