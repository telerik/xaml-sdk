﻿using System.Windows;

namespace HideSelectionRangeTitle
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
