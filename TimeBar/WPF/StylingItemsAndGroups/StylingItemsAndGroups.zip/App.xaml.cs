﻿using System.Windows;

namespace StylingItemsAndGroups
{
	public partial class App : Application
	{
	}
}
