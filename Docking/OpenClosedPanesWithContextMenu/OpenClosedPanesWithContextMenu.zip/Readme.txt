This example demonstrates how to show the closed RadPanes when you close them by their close button also shows how to permanently 
close a RadPane for Silverlight and WPF.