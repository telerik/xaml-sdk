The example demonstrates how to extend the functionality of RadDocking with the use of Attached Properties in order to 
set a collection of Panes as ItemsSource of a specific PaneGroup for Silverlight and WPF.

For more detailed infroamtion could be found in this blog post: 
http://blogs.telerik.com/xamlteam/posts/13-01-14/extending-the-functionality-of-radcontrols-with-attached-properties