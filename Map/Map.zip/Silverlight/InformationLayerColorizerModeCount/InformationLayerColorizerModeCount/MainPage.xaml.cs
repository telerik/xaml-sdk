﻿using System.Windows.Controls;

namespace InformationLayerColorizerModeCount
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
