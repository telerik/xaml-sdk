﻿using System.Windows.Controls;

namespace DistanceAndScaleExternalMapScale
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
