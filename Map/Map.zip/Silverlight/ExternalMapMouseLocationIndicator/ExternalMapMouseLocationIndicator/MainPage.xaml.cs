﻿using System.Windows.Controls;

namespace ExternalMapMouseLocationIndicator
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
