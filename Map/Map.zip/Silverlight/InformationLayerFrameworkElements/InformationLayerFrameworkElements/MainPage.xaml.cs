﻿using System.Windows.Controls;

namespace InformationLayerFrameworkElements
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
