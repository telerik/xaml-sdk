﻿using System.Windows.Controls;

namespace MapShapeReaderToolTipTemplate
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
