﻿using System.Windows.Controls;

namespace MapShapeReaderToolTipStyle
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
