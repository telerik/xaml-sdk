﻿using System.Windows.Controls;

namespace InformationLayerMapLine
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
