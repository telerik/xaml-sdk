﻿using System.Windows.Controls;

namespace InformationLayerHotSpots
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
