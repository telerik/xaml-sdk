﻿using System.Windows.Controls;

namespace InformationLayerMapPolyline
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
