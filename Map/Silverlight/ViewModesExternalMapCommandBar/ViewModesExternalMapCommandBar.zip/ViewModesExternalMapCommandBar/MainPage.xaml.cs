﻿using System.Windows.Controls;

namespace ViewModesExternalMapCommandBar
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
