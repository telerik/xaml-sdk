﻿using System.Windows;

namespace InformationLayerMapShapeProperties
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
