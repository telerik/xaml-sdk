﻿using System.Windows;

namespace InformationLayerColorizerModeRanges
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
