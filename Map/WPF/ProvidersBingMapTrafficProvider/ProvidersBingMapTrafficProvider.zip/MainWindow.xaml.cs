﻿using System.Windows;

namespace ProvidersBingMapTrafficProvider
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
