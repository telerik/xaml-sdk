﻿using System.Windows;

namespace ShapefileMapShapeReader
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
