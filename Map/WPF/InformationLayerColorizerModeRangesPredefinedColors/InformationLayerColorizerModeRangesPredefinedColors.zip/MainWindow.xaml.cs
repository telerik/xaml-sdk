﻿using System.Windows;

namespace InformationLayerColorizerModeRangesPredefinedColors
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
