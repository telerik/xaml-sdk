﻿using System.Windows;

namespace MapShapeReaderToolTipStyle
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
