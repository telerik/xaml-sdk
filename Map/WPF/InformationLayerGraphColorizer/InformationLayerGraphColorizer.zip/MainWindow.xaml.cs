﻿using System.Windows;

namespace InformationLayerGraphColorizer
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
