﻿using System.Windows;

namespace MapShapeReaderToolTipFormat
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
