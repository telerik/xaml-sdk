﻿using System.Windows;

namespace InformationLayerMapPolyline
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
