﻿using System.Windows;

namespace InformationLayerFrameworkElements
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
