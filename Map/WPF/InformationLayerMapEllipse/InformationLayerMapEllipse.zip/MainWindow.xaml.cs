﻿using System.Windows;

namespace InformationLayerMapEllipse
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
