﻿using System.Windows;

namespace ZoomingExternalMapZoomBar
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
