﻿using System.Windows;

namespace InformationLayerMapShapeFill
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
