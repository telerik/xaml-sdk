﻿using System;

namespace DateTimeAxes
{
	public class ChartDataObject
	{
		public DateTime Date
		{
			get;
			set;
		}
		public double Value
		{
			get;
			set;
		}
	}
}
