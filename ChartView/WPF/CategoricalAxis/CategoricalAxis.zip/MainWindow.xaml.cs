﻿using System.Windows;

namespace CategoricalAxis
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
