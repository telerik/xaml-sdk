﻿namespace Selection
{
	public class ChartData
	{
		public double XValue { get; set; }

		public double YValue { get; set; }
	}
}