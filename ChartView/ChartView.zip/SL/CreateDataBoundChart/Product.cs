﻿namespace CreateDataBoundChart
{
	public class Product
	{
		public string Name
		{
			get;
			set;
		}
		public double QuantitySold
		{
			get;
			set;
		}
	}
}
