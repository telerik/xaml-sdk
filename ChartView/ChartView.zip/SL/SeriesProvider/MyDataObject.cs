﻿using System;

namespace SeriesProvider
{
    public class MyDataObject 
    {
        public string Category { get; set; }
        public double Value { get; set; }
    }
}
