﻿using System.Windows.Controls;

namespace AnnotationTypes
{
	public partial class CartesianCustomAnnotationDemo : UserControl
	{
		public CartesianCustomAnnotationDemo()
		{
			InitializeComponent();
		}
	}
}
