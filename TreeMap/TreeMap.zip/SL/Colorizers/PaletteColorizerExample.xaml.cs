﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class PaletteColorizerExample : UserControl
	{
		public PaletteColorizerExample()
		{
			InitializeComponent();
		}
	}
}
