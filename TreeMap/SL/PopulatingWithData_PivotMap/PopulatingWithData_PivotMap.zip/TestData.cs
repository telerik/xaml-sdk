﻿namespace PopulatingWithData_PivotMap
{
	public class TestData
	{
		public int Value { get; set; }
		public string Category { get; set; }
		public string Subcategory { get; set; }
	}
}
