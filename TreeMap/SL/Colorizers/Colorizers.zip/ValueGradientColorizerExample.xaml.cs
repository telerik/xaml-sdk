﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class ValueGradientColorizerExample : UserControl
	{
		public ValueGradientColorizerExample()
		{
			InitializeComponent();
		}
	}
}
