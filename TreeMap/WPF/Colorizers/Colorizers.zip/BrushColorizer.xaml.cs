﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class BrushColorizer : UserControl
	{
		public BrushColorizer()
		{
			InitializeComponent();
		}
	}
}
