﻿using System.Windows.Controls;

namespace Colorizers
{
	public partial class ValueBrushColorizerExampleAbsolute : UserControl
	{
		public ValueBrushColorizerExampleAbsolute()
		{
			InitializeComponent();
		}
	}
}
