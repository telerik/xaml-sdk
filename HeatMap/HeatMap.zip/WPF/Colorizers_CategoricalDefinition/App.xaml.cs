﻿using System.Windows;

namespace Colorizers_CategoricalDefinition
{
	public partial class App : Application
	{
	}
}
