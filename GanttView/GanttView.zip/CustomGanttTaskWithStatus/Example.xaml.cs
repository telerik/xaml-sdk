﻿using System.Windows.Controls;

namespace CustomGanttTaskWithStatus
{
	public partial class Example : UserControl
	{
		public Example()
		{
			InitializeComponent();
		}
	}
}
