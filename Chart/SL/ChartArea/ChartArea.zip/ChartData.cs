﻿using System;

namespace ChartArea
{
	public class ChartData
	{
		public DateTime Date { get; set; }
		public int Value { get; set; }
	}
}