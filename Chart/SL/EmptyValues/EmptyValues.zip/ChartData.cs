﻿using System;

namespace EmptyValues
{
	public class ChartData
	{
		public double? YVal { get; set; }
		public double XVal { get; set; }
	}
}
