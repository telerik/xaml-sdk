﻿For charts that have many data points or data points with values close to one another, labels tend to collide, thus creating a readability problem. The Smart Labels feature automatically re-aligns labels, making each value's label stand out clearly. You are also able to configure the settings for the Smart Labels. This example will show how to:

  - Enable/Disable Smart Labels feature
  - Configure the Smart Labels feature