﻿namespace StripLinesAndGridLines
{
	public class ChartData
	{
		public string XCat { get; set; }
		public int YVal { get; set; }
	}
}