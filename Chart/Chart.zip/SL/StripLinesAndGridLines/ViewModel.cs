﻿using System.Collections;

namespace StripLinesAndGridLines
{
	public class ViewModel
	{
		public IEnumerable Series1Items { get; set; }
		public IEnumerable Series2Items { get; set; }
	}
}
