﻿using System;

namespace DateTimeSupport
{
	public class TradeData
	{
		public DateTime FromDate { get; set; }
		public double Close { get; set; }
	}
}
