﻿namespace ExportToPDF
{
	public class ChartData
	{
		public int XCat { get; set; }
		public int YVal { get; set; }
	}
}
