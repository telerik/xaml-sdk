﻿In is useful when you have static data that will not change in time to create a chart declaratively - in XAML. This example will show you how to:

  - Add a RadChart and set the DefaultView property
  - Add a ChartTitle
  - Add a ChartLegend
  - Add a ChartArea
  - Add a DataSeries