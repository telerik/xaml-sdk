﻿namespace ItemWidthPercentAndItemOverlapPercent
{
	public class ChartData
	{
		public int Quarter { get; set; }
		public int Sales { get; set; }
	}
}
