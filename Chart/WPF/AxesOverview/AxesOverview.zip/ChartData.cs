﻿namespace AxesOverview
{
	public class ChartData
	{
		public int XVal { get; set; }
		public int YVal { get; set; }
	}
}
