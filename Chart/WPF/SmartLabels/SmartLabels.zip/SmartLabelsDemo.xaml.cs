﻿using System.Windows.Controls;

namespace SmartLabels
{
	public partial class SmartLabelsDemo : UserControl
	{
		public SmartLabelsDemo()
		{
			InitializeComponent();
		}
	}
}
