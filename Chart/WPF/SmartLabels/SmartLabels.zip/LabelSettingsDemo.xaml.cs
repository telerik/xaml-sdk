﻿using System.Windows.Controls;

namespace SmartLabels
{
	public partial class LabelSettingsDemo : UserControl
	{
		public LabelSettingsDemo()
		{
			InitializeComponent();
		}
	}
}
