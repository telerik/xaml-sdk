﻿namespace DataBinding
{
	public class Item
	{
		public double Val { get; set; }
		public string Name { get; set; }
	}
}
