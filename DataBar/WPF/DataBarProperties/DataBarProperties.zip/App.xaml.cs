﻿using System.Windows;

namespace DataBarProperties
{
	public partial class App : Application
	{
	}
}
