﻿
namespace NoMatchFilteringBehavior
{
	public class Country
	{
		public string Capital { get; set; }

		public string Name { get; set; }
	}
}
