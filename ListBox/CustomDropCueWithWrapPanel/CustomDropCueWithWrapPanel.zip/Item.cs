﻿namespace CustomDropCueWithWrapPanel
{
	public class Item
	{
		public int Number { get; set; }
	}
}
