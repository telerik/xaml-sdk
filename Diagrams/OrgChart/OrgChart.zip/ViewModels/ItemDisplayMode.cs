﻿namespace OrgChart.ViewModels
{
	public enum ItemDisplayMode
	{
		None,
		Small,
		Standard,
		Detailed,
	}
}
