The idea is to create easy-to-use infrastructure with developer focused examples for all XAML controls. 
The goal is to become high-quality help resource that will ultimately replace our Knowledge Base articles, Code Libraries and "How to" articles in the help. 
It differs from our QSF in that it should be targeting developers and will not be a marketing tool. 