﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace StyleSelectors
{
    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
