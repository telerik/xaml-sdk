﻿using System;
using System.Linq;
using System.Windows;

namespace GlidingConnector
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}
