﻿namespace OrgChart.ViewModels
{
	public enum Branch
	{
		TopManagement,
		Development,
		Sales,
		QA,
	}
}